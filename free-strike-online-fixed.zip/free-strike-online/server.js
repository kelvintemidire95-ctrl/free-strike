const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' }, pingInterval: 25000, pingTimeout: 20000 });
const PORT = process.env.PORT || 10000;
const MAX_PLAYERS = 10;
const players = new Map();
let phase = 'waiting';
let zoneRadius = 105;
let matchStartedAt = 0;
let finished = false;
app.use(express.static(__dirname));
app.get('/health', (_req, res) => res.json({ ok: true, players: players.size, phase }));
function snapshot() {
  const out = {};
  for (const [id, p] of players) out[id] = { id, name: p.name, x: p.x, z: p.z, rot: p.rot, health: p.health, alive: p.alive };
  return { players: out, phase, zoneRadius };
}
function finishIfNeeded() {
  const alive = [...players.values()].filter(p => p.alive);
  if (phase === 'playing' && alive.length <= 1) {
    phase = 'finished'; finished = true;
    io.emit('matchEnd', { winner: alive[0]?.id || null });
  }
}
io.on('connection', socket => {
  socket.on('join', data => {
    if (players.size >= MAX_PLAYERS) { socket.emit('full'); socket.disconnect(true); return; }
    const name = String(data?.name || 'Player').replace(/[<>]/g, '').slice(0, 16) || 'Player';
    const p = { id: socket.id, name, x: (Math.random() - .5) * 50, z: (Math.random() - .5) * 50, rot: 0, health: 100, alive: true, lastShot: 0 };
    players.set(socket.id, p); socket.emit('joined', p); io.emit('state', snapshot());
    if (players.size >= 2 && phase === 'waiting') { phase = 'playing'; matchStartedAt = Date.now(); io.emit('state', snapshot()); }
  });
  socket.on('move', data => {
    const p = players.get(socket.id); if (!p || !p.alive || phase !== 'playing') return;
    const x = Number(data?.x), z = Number(data?.z), rot = Number(data?.rot);
    if (![x,z,rot].every(Number.isFinite)) return;
    // Limit per-packet movement to reduce obvious teleporting.
    const dx = x-p.x, dz = z-p.z;
    if (Math.hypot(dx,dz) > 2.5) return;
    p.x = Math.max(-145, Math.min(145, x)); p.z = Math.max(-145, Math.min(145, z)); p.rot = rot;
  });
  socket.on('shoot', data => {
    const shooter = players.get(socket.id); if (!shooter || !shooter.alive || phase !== 'playing') return;
    const now = Date.now(); if (now - shooter.lastShot < 170) return; shooter.lastShot = now;
    const yaw = Number(data?.yaw); if (!Number.isFinite(yaw)) return;
    // Simple server-side forward-cone hit test for this early prototype.
    let target = null, best = 42;
    for (const p of players.values()) {
      if (p.id === shooter.id || !p.alive) continue;
      const dx = p.x - shooter.x, dz = p.z - shooter.z, dist = Math.hypot(dx,dz);
      if (dist > best || dist < .1) continue;
      const angle = Math.atan2(dx, -dz), diff = Math.atan2(Math.sin(angle-yaw), Math.cos(angle-yaw));
      if (Math.abs(diff) < .13) { best = dist; target = p; }
    }
    if (target) {
      target.health = Math.max(0, target.health - 25);
      if (target.health === 0) target.alive = false;
      io.emit('damage', { target: target.id, health: target.health, by: shooter.id });
      finishIfNeeded();
    }
  });
  socket.on('disconnect', () => {
    players.delete(socket.id);
    if (players.size === 0) {
      phase = 'waiting'; zoneRadius = 105; matchStartedAt = 0; finished = false;
    } else {
      finishIfNeeded();
    }
    io.emit('state', snapshot());
  });
});
setInterval(() => {
  if (phase === 'playing' && !finished && matchStartedAt && Date.now() - matchStartedAt > 45000) {
    zoneRadius = Math.max(12, zoneRadius - .55);
    for (const p of players.values()) {
      if (p.alive && Math.hypot(p.x, p.z) > zoneRadius) { p.health = Math.max(0, p.health - 3); if (!p.health) p.alive = false; }
    }
    finishIfNeeded();
  }
  io.emit('state', snapshot());
}, 250);
server.listen(PORT, '0.0.0.0', () => console.log(`Free Strike server listening on ${PORT}`));
