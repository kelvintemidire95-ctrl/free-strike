# Free Strike Online — first multiplayer rebuild

This project is an online multiplayer battle-royale foundation. The browser client is `index.html`; the authoritative WebSocket game server is `server.js`.

## Features in this build
- 3D island with roads, building clusters, trees, rocks and distant hills.
- Third-person character, keyboard and touch joystick controls.
- Name entry and room matchmaking, up to 10 players per room.
- Server-synchronized player positions, health, kills, ammo and match phase.
- Fire/reload messages, basic server-side hit checks and elimination.
- Shrinking safe zone, survivor count, kill feed and winner screen.
- Health endpoint at `/health`.

## Important scope note
This is the first real online multiplayer foundation, not a finished commercial Free Fire clone. The first version has no plane/parachute, vehicles, full inventory, anti-cheat, persistent accounts, voice chat, squad mode, or professionally commissioned character/weapon assets. Those need subsequent development and testing. The initial hit validation is deliberately simple and should be upgraded before competitive/public release.

## Deploy the server on Render
1. Upload the contents of this folder to the root of the `free-strike` GitHub repository (including `package.json`, `server.js`, `render.yaml`, and `index.html`).
2. In Render, create a **Web Service** connected to that repository, branch `main`.
3. Runtime: Node. Build command: `npm install`. Start command: `npm start`. Region: Singapore. Plan: Free for initial testing.
4. Once the service is created, copy its public `https://...onrender.com` URL.
5. In `index.html`, set `SERVER_URL` to that exact URL (without a trailing slash), commit the change, and let the existing Static Site redeploy the updated `index.html`.

The client currently expects `https://free-strike-server.onrender.com`. If Render assigns a different URL, change that constant to the actual service URL. The client automatically converts it to `wss://` for WebSockets.

## Local test
- `npm install`
- `npm start`
- Open `http://localhost:10000` after temporarily setting `SERVER_URL='http://localhost:10000'` in `index.html`.

Free Render services can sleep when idle, so the first connection may take a little time. A production multiplayer game needs an always-on server, monitoring, rate limits, authoritative physics, and load testing.
