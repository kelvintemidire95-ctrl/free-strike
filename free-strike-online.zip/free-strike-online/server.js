'use strict';
const http = require('http');
const express = require('express');
const { WebSocketServer, WebSocket } = require('ws');
const crypto = require('crypto');

const app = express();
app.get('/health', (_req, res) => res.json({ ok: true, game: 'Free Strike Online', players: players.size, rooms: rooms.size }));
app.get('/status', (_req, res) => res.json({ game: 'Free Strike Online', mode: 'solo', maxPlayers: 10, players: players.size, rooms: rooms.size }));
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true, maxPayload: 16 * 1024 });
const players = new Map();
const rooms = new Map();
const MAX_PLAYERS = 10;
const MAP_LIMIT = 480;
const TICK_MS = 100;
const ZONE_START = 220;

function send(ws, type, data = {}) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type, ...data }));
}
function roomState(room) {
  return {
    roomId: room.id, phase: room.phase, countdown: room.countdown,
    players: [...room.players.values()].map(p => ({ id: p.id, name: p.name, x: p.x, y: p.y, z: p.z, yaw: p.yaw, hp: p.hp, alive: p.alive, kills: p.kills })),
    zone: { x: room.zone.x, z: room.zone.z, radius: room.zone.radius },
    alive: [...room.players.values()].filter(p => p.alive).length
  };
}
function broadcast(room, type, data) {
  const payload = JSON.stringify({ type, ...data });
  for (const p of room.players.values()) if (p.ws.readyState === WebSocket.OPEN) p.ws.send(payload);
}
function assignRoom(player) {
  let room = [...rooms.values()].find(r => r.phase !== 'ended' && r.players.size < MAX_PLAYERS && r.phase !== 'playing');
  if (!room) {
    room = { id: crypto.randomBytes(3).toString('hex').toUpperCase(), players: new Map(), phase: 'waiting', countdown: 20, zone: { x: 0, z: 0, radius: ZONE_START }, startedAt: 0, lastZone: 0 };
    rooms.set(room.id, room);
  }
  room.players.set(player.id, player);
  player.roomId = room.id;
  if (room.players.size >= 2 && room.phase === 'waiting') room.phase = 'countdown';
  send(player.ws, 'joined', { id: player.id, roomId: room.id, slot: room.players.size, maxPlayers: MAX_PLAYERS });
  broadcast(room, 'state', roomState(room));
  return room;
}
function removePlayer(player) {
  if (!player) return;
  const room = rooms.get(player.roomId);
  if (room) {
    room.players.delete(player.id);
    broadcast(room, 'player_left', { id: player.id, state: roomState(room) });
    if (!room.players.size) rooms.delete(room.id);
    else if (room.players.size < 2 && room.phase === 'countdown') { room.phase = 'waiting'; room.countdown = 20; }
  }
  players.delete(player.id);
}
function startMatch(room) {
  room.phase = 'playing'; room.startedAt = Date.now(); room.lastZone = Date.now();
  let i = 0;
  for (const p of room.players.values()) {
    const a = (Math.PI * 2 * i++) / Math.max(room.players.size, 1);
    p.x = Math.cos(a) * 125; p.z = Math.sin(a) * 125; p.y = 0;
    p.hp = 100; p.alive = true; p.kills = 0; p.ammo = 30; p.lastShot = 0;
  }
  broadcast(room, 'match_start', { state: roomState(room), message: 'Match started! Survive to be the last player standing.' });
}
function tick() {
  const now = Date.now();
  for (const room of rooms.values()) {
    if (room.phase === 'countdown') {
      if (room.players.size < 2) { room.phase = 'waiting'; continue; }
      room.countdown -= TICK_MS / 1000;
      if (room.countdown <= 0) startMatch(room);
      else if (Math.floor(room.countdown) !== Math.floor(room.countdown + TICK_MS / 1000)) broadcast(room, 'countdown', { seconds: Math.ceil(room.countdown) });
    }
    if (room.phase === 'playing') {
      const elapsed = now - room.startedAt;
      if (now - room.lastZone > 12000 && room.zone.radius > 28) {
        room.zone.radius = Math.max(28, room.zone.radius - 9);
        room.lastZone = now;
        broadcast(room, 'zone', { zone: room.zone });
      }
      for (const p of room.players.values()) {
        if (!p.alive) continue;
        const dist = Math.hypot(p.x - room.zone.x, p.z - room.zone.z);
        if (dist > room.zone.radius) {
          p.hp = Math.max(0, p.hp - 4);
          if (p.hp === 0) { p.alive = false; send(p.ws, 'eliminated', { by: 'safe zone' }); }
        }
      }
      const alive = [...room.players.values()].filter(p => p.alive);
      if (alive.length <= 1 && room.players.size >= 2) {
        room.phase = 'ended';
        broadcast(room, 'match_end', { winner: alive[0] ? { id: alive[0].id, name: alive[0].name } : null, state: roomState(room) });
      }
      if (elapsed > 18 * 60 * 1000) { room.phase = 'ended'; broadcast(room, 'match_end', { winner: null, state: roomState(room) }); }
      if (now % 300 < TICK_MS) broadcast(room, 'state', roomState(room));
    }
  }
}
setInterval(tick, TICK_MS);

wss.on('connection', ws => {
  let player = null;
  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!player && msg.type === 'join') {
      const name = String(msg.name || 'Survivor').replace(/[^\w -]/g, '').slice(0, 16) || 'Survivor';
      player = { id: crypto.randomUUID(), name, ws, x: 0, y: 0, z: 0, yaw: 0, hp: 100, alive: true, kills: 0, ammo: 30, lastUpdate: Date.now(), lastShot: 0, roomId: null };
      players.set(player.id, player); assignRoom(player); return;
    }
    if (!player) return;
    const room = rooms.get(player.roomId);
    if (!room) return;
    if (msg.type === 'move' && room.phase === 'playing' && player.alive) {
      const now = Date.now(); const dt = Math.min(0.25, Math.max(0.02, (now - player.lastUpdate) / 1000)); player.lastUpdate = now;
      const nx = Number(msg.x), nz = Number(msg.z), yaw = Number(msg.yaw);
      if (!Number.isFinite(nx) || !Number.isFinite(nz) || !Number.isFinite(yaw)) return;
      const maxStep = 11 * dt + 1.2;
      const dx = nx - player.x, dz = nz - player.z, len = Math.hypot(dx, dz);
      const scale = len > maxStep ? maxStep / len : 1;
      player.x = Math.max(-MAP_LIMIT, Math.min(MAP_LIMIT, player.x + dx * scale));
      player.z = Math.max(-MAP_LIMIT, Math.min(MAP_LIMIT, player.z + dz * scale));
      player.yaw = yaw;
    }
    if (msg.type === 'shoot' && room.phase === 'playing' && player.alive) {
      const now = Date.now(); if (now - player.lastShot < 230 || player.ammo <= 0) return;
      player.lastShot = now; player.ammo--;
      const yaw = player.yaw;
      let target = null, best = 42;
      for (const other of room.players.values()) {
        if (other.id === player.id || !other.alive) continue;
        const dx = other.x - player.x, dz = other.z - player.z, d = Math.hypot(dx, dz);
        const targetYaw = Math.atan2(dx, dz);
        let delta = Math.atan2(Math.sin(targetYaw - yaw), Math.cos(targetYaw - yaw));
        if (d < best && Math.abs(delta) < 0.12) { best = d; target = other; }
      }
      if (target) {
        target.hp = Math.max(0, target.hp - 25);
        if (target.hp <= 0) { target.alive = false; player.kills++; send(target.ws, 'eliminated', { by: player.name }); broadcast(room, 'kill', { killer: player.name, victim: target.name }); }
      }
      send(player.ws, 'ammo', { ammo: player.ammo });
    }
    if (msg.type === 'reload') { player.ammo = 30; send(player.ws, 'ammo', { ammo: player.ammo }); }
  });
  ws.on('close', () => removePlayer(player));
  ws.on('error', () => removePlayer(player));
});
server.on('upgrade', (req, socket, head) => {
  if (req.url !== '/ws') { socket.destroy(); return; }
  wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
});
const PORT = Number(process.env.PORT || 10000);
server.listen(PORT, '0.0.0.0', () => console.log(`Free Strike server listening on ${PORT}`));
